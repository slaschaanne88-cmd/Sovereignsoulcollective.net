/**
 * Luminous Threshold page: cinematic sunrise opening, asymmetric editorial flow,
 * specific offer clarity, and separate pathways for new visitors and current members.
 */
import { motion, useReducedMotion } from "framer-motion";
import { useEffect } from "react";
import {
  ArrowUpRight,
  BookOpenText,
  Check,
  Compass,
  HeartHandshake,
  LogIn,
  MessageCircleMore,
} from "lucide-react";
import { brandAssets, skoolAboutUrl, skoolClassroomUrl } from "@/brandAssets";

const journey = [
  {
    days: "Days 1–4",
    title: "Notice",
    text: "Recognise the patterns, reactions, and assumptions shaping your everyday experience.",
  },
  {
    days: "Days 5–9",
    title: "Question",
    text: "Look beneath familiar stories with curiosity—without forcing an answer or adopting someone else’s beliefs.",
  },
  {
    days: "Days 10–14",
    title: "Align",
    text: "Bring insight into grounded choices that feel more honest, conscious, and true to who you are becoming.",
  },
];

const inclusions = [
  {
    icon: BookOpenText,
    title: "Guided reflection",
    text: "A simple rhythm of lessons and questions to help you look beneath the surface.",
  },
  {
    icon: MessageCircleMore,
    title: "Meaningful conversation",
    text: "A private place to share perspectives, ask questions, and learn alongside others.",
  },
  {
    icon: Compass,
    title: "Grounded integration",
    text: "An invitation to turn inner insight into small, conscious changes in everyday life.",
  },
];

const faq = [
  {
    question: "Is the 14-Day Inner Alignment Experiment free?",
    answer:
      "Yes. Sovereign Soul Collective is currently free to join, and the 14-day experience is available inside the private community.",
  },
  {
    question: "Do I need to follow a particular spiritual belief?",
    answer:
      "No. This is a grounded, open-minded space for exploration—not a place where you will be told what to believe.",
  },
  {
    question: "Why does the registration open on Skool?",
    answer:
      "Skool is the private platform where the lessons, conversations, and shared experience are hosted. It may ask you to create or sign into a free account.",
  },
  {
    question: "Is this therapy or psychological treatment?",
    answer:
      "No. The collective supports personal reflection and community learning; it is not a substitute for medical or psychological care.",
  },
];

function Enter({
  children,
  delay = 0,
  className = "",
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const reduceMotion = useReducedMotion();

  return (
    <motion.div
      className={className}
      initial={reduceMotion ? false : { opacity: 0, y: 18 }}
      whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.6, delay, ease: [0.23, 1, 0.32, 1] }}
    >
      {children}
    </motion.div>
  );
}

function ActionLink({
  href,
  label,
  variant = "primary",
}: {
  href: string;
  label: string;
  variant?: "primary" | "secondary" | "nav";
}) {
  return (
    <a href={href} className={`action-link action-link--${variant}`}>
      <span>{label}</span>
      {variant === "secondary" ? (
        <LogIn aria-hidden="true" size={18} strokeWidth={1.8} />
      ) : (
        <ArrowUpRight aria-hidden="true" size={18} strokeWidth={1.8} />
      )}
    </a>
  );
}

function CommunityActions({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`community-actions ${compact ? "community-actions--compact" : ""}`}>
      <ActionLink href={skoolAboutUrl} label="Join the free community" />
      <ActionLink href={skoolClassroomUrl} label="Member classroom" variant="secondary" />
    </div>
  );
}

export default function Home() {
  useEffect(() => {
    document.title = "Free 14-Day Inner Alignment | Sovereign Soul Collective";
  }, []);

  return (
    <div className="site-shell">
      <header className="masthead">
        <a href="#top" className="brand" aria-label="Sovereign Soul Collective home">
          <img
            src={brandAssets.suppliedSeal}
            alt="Sovereign Soul Collective moon and gold emblem"
            className="brand__symbol"
          />
          <span className="brand__words">
            <span>Sovereign Soul</span>
            <small>Collective</small>
          </span>
        </a>
        <nav aria-label="Main navigation">
          <a href="#journey">The journey</a>
          <a href="#about">About</a>
          <ActionLink href={skoolClassroomUrl} label="Classroom" variant="nav" />
        </nav>
      </header>

      <main id="top">
        <section className="hero" aria-labelledby="hero-title">
          <div className="hero__media">
            <img
              src={brandAssets.suppliedHero}
              alt="A person sitting in reflection above a mountain valley at sunrise"
            />
            <div className="hero__wash" />
          </div>
          <motion.div
            className="hero__copy"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}
          >
            <p className="eyebrow eyebrow--dark">A free guided inner-development experience</p>
            <h1 id="hero-title">
              The 14-Day Inner
              <em> Alignment Experiment</em>
            </h1>
            <p className="hero__intro">
              Create the space to notice what is shaping you—and begin choosing your life with greater clarity,
              freedom, and intention.
            </p>
            <p className="hero__proof">Free to join · Hosted privately on Skool</p>
          </motion.div>
        </section>

        <section className="offer-card" aria-label="Join the experiment">
          <div className="offer-card__marker">14</div>
          <div className="offer-card__content">
            <p className="eyebrow">The experiment is open</p>
            <h2>Fourteen days to listen beneath the noise.</h2>
            <p>
              Join a grounded, curious community exploring consciousness, subconscious patterns, and the choices
              that bring you back into alignment with yourself.
            </p>
          </div>
          <div className="offer-card__action">
            <CommunityActions compact />
            <small>New here? Join first. Already a member? Go straight to the classroom.</small>
          </div>
        </section>

        <section className="recognition section-pad">
          <div className="recognition__title">
            <Enter>
              <p className="eyebrow">A quiet recognition</p>
              <h2>When life looks fine on the surface, but something deeper is asking to be heard.</h2>
            </Enter>
          </div>
          <div className="recognition__body">
            <Enter delay={0.08}>
              <p className="lead">
                You may sense that familiar patterns are creating resistance, yet struggle to find a space where
                you can question, reflect, and grow without being forced into someone else’s answers.
              </p>
              <p>
                Sovereign Soul Collective offers a grounded environment for exploring the inner world with
                curiosity. The 14-day experiment gives that exploration a clear beginning, a gentle structure, and
                a community to walk beside you.
              </p>
            </Enter>
          </div>
        </section>

        <div className="ornament" aria-hidden="true">
          <img
            src={brandAssets.horizonOrnament}
            alt="Gold horizon ornament marking the inner alignment journey"
          />
        </div>

        <section id="journey" className="journey section-pad">
          <Enter className="section-heading">
            <p className="eyebrow">The arc of the experience</p>
            <h2>Not a demand to reinvent yourself. An invitation to meet yourself more honestly.</h2>
          </Enter>
          <div className="journey__steps">
            {journey.map((item, index) => (
              <Enter key={item.title} delay={index * 0.07} className="journey-step">
                <div className="journey-step__index">0{index + 1}</div>
                <p className="journey-step__days">{item.days}</p>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </Enter>
            ))}
          </div>
        </section>

        <section className="inside">
          <div className="inside__visual" aria-hidden="true">
            <img
              src={brandAssets.dawnVeil}
              alt="Charcoal and dawn light background representing inner clarity"
            />
          </div>
          <div className="inside__content section-pad">
            <Enter className="section-heading section-heading--compact">
              <p className="eyebrow">Inside the collective</p>
              <h2>A clear container for inner exploration.</h2>
            </Enter>
            <div className="inclusions">
              {inclusions.map((item, index) => {
                const Icon = item.icon;
                return (
                  <Enter key={item.title} delay={index * 0.07} className="inclusion">
                    <Icon size={24} strokeWidth={1.4} aria-hidden="true" />
                    <div>
                      <h3>{item.title}</h3>
                      <p>{item.text}</p>
                    </div>
                  </Enter>
                );
              })}
            </div>
          </div>
        </section>

        <section id="about" className="about section-pad">
          <div className="about__portrait">
            <Enter>
              <div className="about__portrait-frame">
                <img
                  src={brandAssets.founderPortrait}
                  alt="Sascha Herdman, founder of Sovereign Soul Collective, with her dog"
                  className="about__founder-photo"
                />
                <img
                  src={brandAssets.suppliedSeal}
                  alt="Sovereign Soul Collective circular emblem"
                  className="about__seal"
                />
              </div>
            </Enter>
          </div>
          <div className="about__copy">
            <Enter delay={0.08}>
              <p className="eyebrow">Founded by Sascha Herdman</p>
              <h2>A place to explore—not a place to be told what to believe.</h2>
              <p className="lead">
                Sovereign Soul Collective brings together consciousness, spirituality, transpersonal development,
                self-awareness, and human potential in a grounded, open-minded way.
              </p>
              <p>
                You do not need all the answers or a particular belief system. You only need curiosity about
                yourself and a willingness to turn insight into everyday change.
              </p>
              <div className="about__note">
                <HeartHandshake size={22} aria-hidden="true" />
                <span>Private community · Personal reflection · Shared perspectives</span>
              </div>
            </Enter>
          </div>
          <img
            src={brandAssets.botanicalArc}
            alt="Gold and olive botanical branch"
            className="about__botanical"
            aria-hidden="true"
          />
        </section>

        <section className="handoff section-pad">
          <div className="handoff__intro">
            <Enter>
              <p className="eyebrow">Choose your next step</p>
              <h2>Join the collective—or return directly to your classroom.</h2>
              <p>
                New visitors can review the community and join free on the public About page. Existing members can
                bypass that page and open the Classroom directly.
              </p>
            </Enter>
          </div>
          <Enter delay={0.08} className="handoff__steps">
            <div className="route-card">
              <span>New here</span>
              <h3>Meet the collective</h3>
              <p>Review the community, see that it is free, and complete your registration.</p>
              <ActionLink href={skoolAboutUrl} label="Open the About page" />
            </div>
            <div className="route-card route-card--member">
              <span>Already a member</span>
              <h3>Continue the journey</h3>
              <p>Go straight to the lessons and resources inside your member classroom.</p>
              <ActionLink href={skoolClassroomUrl} label="Open the classroom" variant="secondary" />
            </div>
          </Enter>
        </section>

        <section className="faq section-pad">
          <div className="faq__heading">
            <p className="eyebrow">Before you step inside</p>
            <h2>Questions, answered simply.</h2>
          </div>
          <div className="faq__list">
            {faq.map((item) => (
              <details key={item.question}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </section>

        <section className="final-cta">
          <div className="final-cta__mark">
            <img src={brandAssets.suppliedSeal} alt="Sovereign Soul Collective emblem" />
          </div>
          <p className="eyebrow">Explore · Connect · Grow · Evolve</p>
          <h2>What might become possible when you stop abandoning your own inner knowing?</h2>
          <CommunityActions />
          <small>New visitors join via the About page · Existing members can open the Classroom directly</small>
        </section>
      </main>

      <footer>
        <div className="footer__brand">
          <span>Sovereign Soul Collective</span>
          <small>Consciousness · Inner development · Human potential</small>
        </div>
        <p>© {new Date().getFullYear()} Sovereign Soul Collective</p>
      </footer>
    </div>
  );
}
